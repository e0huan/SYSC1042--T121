#Elaine Huang
#Mohammad Abu Hammad
#Camden Erwin
#Brandon Wu

def check_equal(expected, actual):
    if expected == actual:
        print("passed")
    else:
        print("failed")
